// 2. DOM ELEMENTS
// ============================================
const fileInput = document.getElementById("fileInput");
const cardImageArea = document.getElementById("cardImageArea");
const uploadPrompt = document.getElementById("uploadPrompt");
const generateOverlay = document.getElementById("generateOverlay");
const generateBtn = document.getElementById("generateBtn");
const refThumbsRow = document.getElementById("refThumbsRow");
const generatedGrid = document.getElementById("generatedGrid");
const fullImageView = document.getElementById("fullImageView");
const publishBtn = document.getElementById("publishBtn");

// Form elements
const linkName = document.getElementById("linkName");
const caption = document.getElementById("caption");
const description = document.getElementById("description");
const linkUrl = document.getElementById("linkUrl");

// ============================================
