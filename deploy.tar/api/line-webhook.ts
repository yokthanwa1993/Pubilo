import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';

// Disable automatic body parsing to get raw body for signature verification
export const config = {
  api: {
    bodyParser: false,
  },
};

const supabase = createClient(
  process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const LINE_CHANNEL_SECRET = process.env.LINE_CHANNEL_SECRET || '';
const LINE_CHANNEL_ACCESS_TOKEN = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';

function verifySignature(body: string, signature: string): boolean {
  if (!LINE_CHANNEL_SECRET) return true; // Skip if not configured
  const hash = crypto.createHmac('sha256', LINE_CHANNEL_SECRET).update(body).digest('base64');
  return hash === signature;
}

// Helper to get raw body from request
async function getRawBody(req: VercelRequest): Promise<string> {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
    });
    req.on('end', () => {
      resolve(data);
    });
    req.on('error', reject);
  });
}

async function replyMessage(replyToken: string, text: string) {
  if (!LINE_CHANNEL_ACCESS_TOKEN) return;
  
  const now = new Date();
  const timeStr = now.toLocaleDateString('th-TH', { day: '2-digit', month: '2-digit', year: '2-digit' }) + ' ' + 
                  now.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' });
  
  const flexMessage = {
    type: 'flex',
    altText: 'เพิ่มคำคมสำเร็จ',
    contents: {
      type: 'bubble',
      header: {
        type: 'box',
        layout: 'vertical',
        contents: [{ type: 'text', text: 'QUOTE', weight: 'bold', size: 'xl', color: '#ffffff', align: 'center' }],
        backgroundColor: '#27AE60'
      },
      body: {
        type: 'box',
        layout: 'vertical',
        contents: [
          {
            type: 'box',
            layout: 'baseline',
            contents: [
              { type: 'text', text: '📊 สถานะ:', size: 'md', color: '#555555', flex: 2 },
              { type: 'text', text: 'สำเร็จ ✅', size: 'md', color: '#27AE60', flex: 3, weight: 'bold' }
            ],
            margin: 'md'
          },
          {
            type: 'box',
            layout: 'vertical',
            contents: [
              { type: 'text', text: '📝 ข้อความที่ได้รับ:', size: 'md', color: '#555555' },
              {
                type: 'box',
                layout: 'vertical',
                contents: [{ type: 'text', text: text, size: 'md', color: '#333333', wrap: true }],
                backgroundColor: '#F5F5F5',
                paddingAll: 'md',
                cornerRadius: 'md',
                margin: 'sm'
              }
            ],
            margin: 'xl'
          },
          {
            type: 'box',
            layout: 'baseline',
            contents: [
              { type: 'text', text: '🕐 เวลา:', size: 'md', color: '#555555', flex: 2 },
              { type: 'text', text: timeStr, size: 'md', color: '#333333', flex: 3 }
            ],
            margin: 'xl'
          }
        ]
      }
    }
  };

  await fetch('https://api.line.me/v2/bot/message/reply', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}`,
    },
    body: JSON.stringify({
      replyToken,
      messages: [flexMessage],
    }),
  });
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  console.log('[line-webhook] === REQUEST START ===', req.method);

  try {
    if (req.method === 'GET') {
      return res.status(200).send('LINE Webhook OK');
    }

    if (req.method !== 'POST') {
      return res.status(405).end();
    }

    // Get raw body for signature verification
    const rawBody = await getRawBody(req);
    console.log('[line-webhook] Raw body length:', rawBody.length);
    console.log('[line-webhook] Raw body preview:', rawBody.substring(0, 500));

    const signature = req.headers['x-line-signature'] as string;

    // Verify signature using raw body
    if (!verifySignature(rawBody, signature)) {
      console.log('[line-webhook] Invalid signature');
      return res.status(401).end();
    }

    // Parse body after signature verification
    const body = JSON.parse(rawBody);
    console.log('[line-webhook] Parsed body, events:', body.events?.length);

    const { events } = body;

  for (const event of events || []) {
    console.log('[line-webhook] Event type:', event.type, 'Message type:', event.message?.type);

    if (event.type !== 'message') continue;

    // Handle stickers - reply that we don't support them
    if (event.message.type === 'sticker') {
      console.log('[line-webhook] Sticker received, skipping');
      try {
        await replyMessage(event.replyToken, '⚠️ ไม่รองรับ Sticker กรุณาส่งเป็นข้อความ');
      } catch (e) {
        console.error('[line-webhook] Failed to reply sticker message');
      }
      continue;
    }

    // Only process text messages
    if (event.message.type !== 'text') {
      console.log('[line-webhook] Non-text message type:', event.message.type);
      continue;
    }

    let text = event.message.text || '';
    console.log('[line-webhook] Raw text:', JSON.stringify(text));
    console.log('[line-webhook] Text bytes:', Buffer.from(text).toString('hex').substring(0, 100));

    // Handle LINE emoji - they appear as placeholders in text
    if (event.message.emojis && Array.isArray(event.message.emojis)) {
      console.log('[line-webhook] LINE emojis found:', JSON.stringify(event.message.emojis));
    }

    text = text.trim();
    console.log('[line-webhook] After trim, length:', text.length);
    if (!text) {
      console.log('[line-webhook] Empty text after trim, skipping');
      continue;
    }

    // Special command: earnings summary
    if (text.toLowerCase() === 'earnings' || text.toLowerCase() === '/earnings') {
      console.log('[line-webhook] Earnings request');
      try {
        // Get pages with tokens and colors
        const { data: pages } = await supabase
          .from('page_settings')
          .select('page_id, page_name, page_color, post_token')
          .eq('auto_schedule', true)
          .not('post_token', 'is', null);

        if (!pages || pages.length === 0) {
          await fetch('https://api.line.me/v2/bot/message/reply', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}` },
            body: JSON.stringify({ replyToken: event.replyToken, messages: [{ type: 'text', text: '❌ ไม่มีเพจที่เปิด auto_schedule' }] }),
          });
          continue;
        }

        // Fetch from Facebook directly
        const results: any[] = [];
        let earningsDate = '';
        
        for (const page of pages) {
          try {
            const fbUrl = `https://graph.facebook.com/v21.0/${page.page_id}/insights?metric=monetization_approximate_earnings&access_token=${page.post_token}`;
            const fbResponse = await fetch(fbUrl);
            const fbData = await fbResponse.json();
            
            if (fbData.error) continue;
            
            const dailyData = fbData.data?.find((d: any) => d.period === 'day');
            const weeklyData = fbData.data?.find((d: any) => d.period === 'week');
            const monthlyData = fbData.data?.find((d: any) => d.period === 'days_28');
            
            const latestDaily = dailyData?.values?.[dailyData.values.length - 1];
            if (latestDaily?.end_time && !earningsDate) earningsDate = latestDaily.end_time;
            
            results.push({
              pageName: page.page_name,
              pageColor: page.page_color || '#666666',
              daily: latestDaily?.value || 0,
              weekly: weeklyData?.values?.[weeklyData.values.length - 1]?.value || 0,
              monthly: monthlyData?.values?.[monthlyData.values.length - 1]?.value || 0
            });
          } catch (e) { continue; }
        }

        if (results.length === 0) {
          await fetch('https://api.line.me/v2/bot/message/reply', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}` },
            body: JSON.stringify({ replyToken: event.replyToken, messages: [{ type: 'text', text: '❌ ไม่สามารถดึงข้อมูลรายได้ได้' }] }),
          });
          continue;
        }

        results.sort((a, b) => b.daily - a.daily);
        const totalDaily = results.reduce((sum, r) => sum + r.daily, 0);
        const totalWeekly = results.reduce((sum, r) => sum + r.weekly, 0);
        const totalMonthly = results.reduce((sum, r) => sum + r.monthly, 0);
        const d = new Date(earningsDate);
        const displayDate = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;

        const pageContents = results.map(r => ({
          type: 'box', layout: 'horizontal',
          contents: [
            { type: 'box', layout: 'vertical', contents: [{ type: 'text', text: '●', size: 'xs', color: r.pageColor }], width: '20px', alignItems: 'center', justifyContent: 'center' },
            { type: 'box', layout: 'vertical', contents: [{ type: 'text', text: r.pageName, size: 'sm', color: '#333333', weight: 'bold' }], flex: 4 },
            { type: 'box', layout: 'vertical', contents: [{ type: 'text', text: `$${r.daily.toFixed(2)}`, size: 'md', color: r.pageColor, weight: 'bold', align: 'end' }], flex: 3 }
          ],
          backgroundColor: '#F8F9FA', paddingAll: 'md', cornerRadius: 'lg', margin: 'sm'
        }));

        const flexMessage = {
          type: 'flex', altText: `💰 รายได้วันนี้: $${totalDaily.toFixed(2)}`,
          contents: {
            type: 'bubble', size: 'mega',
            body: {
              type: 'box', layout: 'vertical', paddingAll: 'lg', backgroundColor: '#ffffff',
              contents: [
                { type: 'box', layout: 'horizontal', contents: [{ type: 'text', text: '💰 Earnings', size: 'md', color: '#333333', weight: 'bold', flex: 1 }, { type: 'text', text: displayDate, size: 'xs', color: '#999999', align: 'end', gravity: 'center' }], paddingBottom: 'lg' },
                { type: 'box', layout: 'vertical', contents: [{ type: 'text', text: 'TODAY', size: 'xs', color: '#666666', align: 'center' }, { type: 'text', text: `$${totalDaily.toFixed(2)}`, size: 'xxl', weight: 'bold', color: '#1DB954', align: 'center' }], backgroundColor: '#E8F5E9', paddingAll: 'lg', cornerRadius: 'lg' },
                { type: 'box', layout: 'horizontal', contents: [{ type: 'box', layout: 'vertical', contents: [{ type: 'text', text: 'WEEKLY', size: 'xxs', color: '#666666', align: 'center' }, { type: 'text', text: `$${totalWeekly.toFixed(2)}`, size: 'lg', weight: 'bold', color: '#2196F3', align: 'center' }], flex: 1, backgroundColor: '#E3F2FD', paddingAll: 'md', cornerRadius: 'md' }, { type: 'box', layout: 'vertical', contents: [], width: '8px' }, { type: 'box', layout: 'vertical', contents: [{ type: 'text', text: '28-DAY', size: 'xxs', color: '#666666', align: 'center' }, { type: 'text', text: `$${totalMonthly.toFixed(2)}`, size: 'lg', weight: 'bold', color: '#FF5722', align: 'center' }], flex: 1, backgroundColor: '#FBE9E7', paddingAll: 'md', cornerRadius: 'md' }], margin: 'md', paddingBottom: 'lg' },
                { type: 'separator', color: '#EEEEEE' },
                { type: 'box', layout: 'horizontal', contents: [{ type: 'text', text: 'PAGE', size: 'xs', color: '#999999' }], paddingTop: 'lg', paddingBottom: 'md' },
                ...pageContents
              ]
            }
          }
        };

        await fetch('https://api.line.me/v2/bot/message/reply', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}` },
          body: JSON.stringify({ replyToken: event.replyToken, messages: [flexMessage] }),
        });
      } catch (err) {
        console.error('[line-webhook] Earnings error:', err);
        await fetch('https://api.line.me/v2/bot/message/reply', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}` },
          body: JSON.stringify({ replyToken: event.replyToken, messages: [{ type: 'text', text: '❌ เกิดข้อผิดพลาด' }] }),
        });
      }
      continue;
    }

    // Special command: get LINE user ID
    if (text.toLowerCase() === 'id' || text.toLowerCase() === '/id') {
      const userId = event.source?.userId || 'Unknown';
      console.log('[line-webhook] User ID request from:', userId);

      const idFlexMessage = {
        type: 'flex',
        altText: `Your LINE User ID: ${userId}`,
        contents: {
          type: 'bubble',
          header: {
            type: 'box',
            layout: 'vertical',
            contents: [{ type: 'text', text: '🆔 LINE USER ID', weight: 'bold', size: 'lg', color: '#ffffff', align: 'center' }],
            backgroundColor: '#3498DB'
          },
          body: {
            type: 'box',
            layout: 'vertical',
            contents: [
              { type: 'text', text: 'Your LINE User ID:', size: 'sm', color: '#999999' },
              {
                type: 'box',
                layout: 'vertical',
                contents: [{ type: 'text', text: userId, size: 'sm', color: '#333333', wrap: true }],
                backgroundColor: '#F5F5F5',
                paddingAll: 'md',
                cornerRadius: 'md',
                margin: 'sm'
              },
              { type: 'text', text: 'เอา ID นี้ไปใส่ใน Vercel Environment Variables:', size: 'xs', color: '#999999', margin: 'xl', wrap: true },
              { type: 'text', text: 'LINE_USER_ID', size: 'sm', color: '#E74C3C', weight: 'bold', margin: 'sm' }
            ]
          }
        }
      };

      await fetch('https://api.line.me/v2/bot/message/reply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}`,
        },
        body: JSON.stringify({
          replyToken: event.replyToken,
          messages: [idFlexMessage],
        }),
      });
      continue;
    }

    try {
      console.log('[line-webhook] Inserting to DB, text bytes:', Buffer.from(text).length);
      const { data, error } = await supabase.from('quotes').insert({ quote_text: text }).select();

      if (error) {
        console.error('[line-webhook] DB Error:', JSON.stringify(error));
        throw error;
      }

      console.log('[line-webhook] DB insert success:', JSON.stringify(data));
      console.log('[line-webhook] Sending reply...');
      await replyMessage(event.replyToken, text);
      console.log('[line-webhook] Reply sent successfully');
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : (typeof err === 'object' && err !== null ? JSON.stringify(err) : String(err));
      console.error('[line-webhook] Error:', errorMsg);
      console.error('[line-webhook] Error stack:', err instanceof Error ? err.stack : 'N/A');
      // ลองตอบกลับแม้ insert ไม่สำเร็จ
      try {
        await replyMessage(event.replyToken, '❌ เกิดข้อผิดพลาด: ' + errorMsg);
      } catch (replyErr) {
        console.error('[line-webhook] Reply error also failed:', replyErr instanceof Error ? replyErr.message : JSON.stringify(replyErr));
      }
    }
  }

    return res.status(200).end();
  } catch (globalErr) {
    console.error('[line-webhook] === GLOBAL ERROR ===', globalErr instanceof Error ? globalErr.message : JSON.stringify(globalErr));
    console.error('[line-webhook] Stack:', globalErr instanceof Error ? globalErr.stack : 'N/A');
    return res.status(500).json({ error: 'Internal error' });
  }
}
